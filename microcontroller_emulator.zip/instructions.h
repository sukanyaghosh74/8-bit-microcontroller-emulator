#ifndef INSTRUCTIONS_H
#define INSTRUCTIONS_H

#include "emulator.h"

// Function to execute an instruction
void execute_instruction(Emulator *emu, unsigned char opcode);

#endif
